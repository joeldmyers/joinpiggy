$(function(){

	/* Custom Dropdown */
	$('#search-options').customSelect();

	/* Tool Tips */
	$('#navigation a').tipsy();

	/* Dropdown Menu for Account */
	$('#navigation ul').dcMegaMenu();




	/* USED TO CONTROL THE MODALS */
    // Trigger Modal
    // $('#inter-signup-modal').modal({
    //     backdrop: 'static'
    // }).modal('show');

    // $('#signup-modal').modal({
    //     backdrop: 'static'
    // }).modal('show');
});