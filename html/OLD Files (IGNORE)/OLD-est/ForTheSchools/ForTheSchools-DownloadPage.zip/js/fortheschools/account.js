$(function(){
	$('select').customSelect();
});