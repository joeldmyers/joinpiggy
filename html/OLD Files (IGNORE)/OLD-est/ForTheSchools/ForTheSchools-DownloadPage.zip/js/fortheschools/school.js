Circles.create({
    id:         'circles-1',
    percentage: 50,
    radius:     60,
    width:      10,
    number:     50,
    text:       '<p><i>%</i><span>Goal</span> <b>Raised</b></p>',
    colors:     ['#efa29f', '#e24e4e'],
    duration:   400
});
Circles.create({
    id:         'circles-2',
    percentage: 50,
    radius:     60,
    width:      10,
    number:     50,
    text:       '<p><i>%</i><span>Goal</span> <b>Raised</b></p>',
    colors:     ['#efa29f', '#e24e4e'],
    duration:   400
});