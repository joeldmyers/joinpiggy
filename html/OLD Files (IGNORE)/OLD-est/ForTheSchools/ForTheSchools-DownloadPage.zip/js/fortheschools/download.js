$(function(){
	$('#display').after('<ul id="nav">').cycle({ 
        fx:     'fade', 
        speed:  'fast', 
        timeout: 0
    });
});