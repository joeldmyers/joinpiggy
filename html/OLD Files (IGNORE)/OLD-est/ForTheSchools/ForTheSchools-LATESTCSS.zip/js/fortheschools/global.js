$(function(){
	/* Custom Dropdown */
	$('#iama').customSelect();

	/* Tool Tips */
	$('#navigation a').tipsy();

	/* Dropdown Menu for Account */
	$('#navigation ul').dcMegaMenu();


	
    // Trigger Modal
    // $('#inter-signup-modal').modal({
    //     backdrop: 'static'
    // }).modal('show');

    // $('#signup-modal').modal({
    //     backdrop: 'static'
    // }).modal('show');
});