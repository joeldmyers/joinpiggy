function Icon() {
	var TIMEOUT_INTERVAL = 100;
	var CYCLES_COUNT = 1;
	var index = 0;
	var timeout;
	var type;
	var images;

	switch(framework.browser.name) {
		case 'Safari': 
			images = {
				'default': 'icon-bw.png',
				'active': 'icon-bw.png',
				'inactive': 'icon-bw.png'
			}; 
			break;
		case 'Internet Explorer':
		case 'Chrome':
		case 'Firefox':
			images = {
				'default': 'icon-18.png',
				'active': [
					'icon-18.png',
					'green-icon-18.png',
				],
				'inactive': [
					'icon-18.png',
					'red-icon-18.png',
				]
			};
			break;
	};

	function setIcon(url) {
		framework.ui.button.setIcon('img/' + url);
	}

	function frame() {
		setIcon(images[type][index % images[type].length]);
		if (++index/images[type].length >= CYCLES_COUNT) {
			window.clearInterval(timeout);
		}
	}

	this.play = function(opt_type) {
		type = opt_type || 'default';
		index = 0;
		window.clearInterval(timeout);
		if( typeof images[type] === 'string') {
			setIcon(images[type]);
		} else {
			timeout = setInterval(frame, TIMEOUT_INTERVAL);
		}
		
	};
}