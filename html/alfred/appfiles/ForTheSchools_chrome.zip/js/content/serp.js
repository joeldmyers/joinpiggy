var cssInjected = false;
function PursePerksSERPOverlay(){
	//-- Rules to detect SERP pages and parse out correct URLs from these pages
	var config = [{
		domain: 'search.yahoo.com',
		rx: /\/search.*fr=.*/,
		pattern: 'div#main h3 a.spt',
		hrefrx: /=(https?:\/\/.+?)\/\//
	},{
		domain: 'www.bing.com',
		rx: /\/?search/,
		pattern: '#b_results h2 > a'
	},{
		domain: 'google.',
		rx: /^http(?:s)?:\/\/(?:www\.|encrypted\.)?google(?:\.com?)?\..{2,3}\/#?(?:search|webhp|sclient|hl|)?.*[&]?q=([^&]*)/,
		pattern: 'div.rc > .r > a'
	}];




	function getMerchant(url, callback){
		framework.extension.fireEvent('getStore', { 
			'data': {
				'url': url
			}
		}, function(data){
			if (data) {
				callback(data);
			}
		});
	}

	function renderHTML(node, merchant){
		if(!cssInjected){
			injectCSS();
			cssInjected = true;
		}

        if(merchant['store_discount'] == "") {
            $(node).before(
                $('<div />').addClass('pp-serp-div').append(
                    $('<span />').addClass('pp-serp-logo')
                ).append(
                    $('<span />').addClass('pp-serp-text').text('Get Special Deals at '+merchant['store_name']+'!' )
                )
            );
        } else {
            $(node).before(
                $('<div />').addClass('pp-serp-div').append(
                    $('<span />').addClass('pp-serp-logo')
                ).append(
                    $('<span />').addClass('pp-serp-text').text('Get Up to '+merchant['store_discount']+'% Cash Back at '+merchant['store_name']+'!' )
                )
            );
        }
	}

	$.each(config, function(i, serp){
		if(location.href.indexOf(serp.domain) >= 0){
			if(serp.rx.test(location.href)){
				$(serp.pattern, document).each(function(){
					if(this.getAttribute('href') && (this.getAttribute('href').indexOf('http') == 0) && (this.getAttribute('pp-serp-processed') != '1')){

						this.setAttribute('pp-serp-processed', '1');
						var id, node = this;
						var href = node.getAttribute('href');
						if (href.indexOf('url=http')>0){
							href = href.match(/url=([^&]+)/).pop();
						}

						if (serp.hrefrx) {
							var match = unescape(href).match(serp.hrefrx);
							if (match && match.length == 2) {
								href = match[1];
							}
						}
						getMerchant( href, function(merchant){
							if(merchant && merchant['store_discount'] != '0'){
								renderHTML(node, merchant);
							}
						});
					}
				});
				return false;			
			}
		}
	});
}


//---------------------------------------------------
//-- Set up page analyzer 

$(window).bind('load hashchange', PursePerksSERPOverlay);
window.setInterval(PursePerksSERPOverlay, 1500);
