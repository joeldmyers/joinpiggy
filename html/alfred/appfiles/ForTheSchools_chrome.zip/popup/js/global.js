
function CFPopup() {
	var bg = framework.extension.getBackgroundPage();
	var PP = bg.PP;
    var adjustPopupSizeAttempt = 5;
    var dealsItems = 10;
    var activationInterval;
    var current_merchant;
    var current_account;
    var current_earnings;
    var account_checked = false;
    var merchant_checked = false;
    var client; 

    function init(){
        adjustPopupSize();
        setBehaviors();
        setMerchant();
        setAccount();
        checkNotificationsDisabled();

    }

    function adjustPopupSize() {
        var dx = 0, 
            dy = 4;
        if (framework.browser.name === 'Internet Explorer') {
            dy = 2; dx = 2;
        }
        var height = $("body").height();
        framework.ui.button.setPopup({
            'url': 'popup/widget.html',
            'height': height + dy, 
            'width': 480 + dx
        });
        if (adjustPopupSizeAttempt-- > 0) {
            window.setTimeout(adjustPopupSize, 200);
        }
    }


    function setBehaviors(){        
        
        $(document.body).delegate('a[data-href]', 'click', function() {
            var coupon_code = $(this).attr("data-coupon_code");
            var is_merchant = $(this).attr("data-is_merchant");
            //If this is a coupon, copy code to clipboard 
            if (coupon_code!=""){
                if (framework.browser.name=="Safari" ){
                    var coupon_input = $("<input>").addClass("copycode").attr("id","input-coupon-"+coupon_code).attr("type","text").val(coupon_code).click(function(){

                    });                    
                    $(this).after(
                        $("<div>").addClass("input-group")
                        .append($("<div>").addClass("input-group-addon").html("COPY"))
                        .append(coupon_input)
                        .append($("<em>").html("Hit ctrl-c to copy to clipboard"))
                    ).hide();
                    coupon_input.focus().select();
                }
                else{
                    framework.extension.fireEvent('CopyToClipboard', { data: {
                        text: coupon_code
                    }});
                    $(this).after(
                        $("<div>").addClass("code-copy-input")
                        .append($("<em>").html("Code copied to clipboard."))
                    );

                }
            }

            //Only if coupon on this merchant and merchant not active, do background activation
            if (coupon_code!=""){
                if (is_merchant=="1" &&  !(current_merchant.activated)){ 
                    var activate_btn=$(this);
                    activate_btn.append('&nbsp;<i class="fa fa-circle-o-notch fa-spin"></i>');
                    PP.activate(current_merchant,function(){
                        activate_btn.find("i").remove();
                        setActive();
                    });                    
                }                
            }
            else{
                //If its a deal on this merchant, open it in same window
                if (is_merchant==1){
                    framework.browser.navigate({
                        'url': PP.substitute(this.getAttribute('data-href'))
                    });                    
                }
                else{
                    //If we are not in a merchant site, open deals in new window
                    framework.browser.navigate({
                        'url': PP.substitute(this.getAttribute('data-href')),
                        'tabId': framework.browser.NEWTAB
                    });                     
                }
                window.close();                
            }
        });

        if (PP.debug){
            $("footer p").click(function(){            
                $("footer").find("em").remove();
                $("footer").append($("<em>").html(PP.app_uid));
            });
        }

        $("a.widget-close").click(function(){
            window.close();
        });

        $("a.view-account").click(function(){
            if(!current_account){
                $( ".section-slide" ).slideToggle( "slow", function() {
                    return false;
                });
            }  
            else{
                framework.browser.navigate({
                    'url': PP.substitute("{host}/account/update"),
                    'tabId': framework.browser.NEWTAB
                });                            
            }            
        })

        $("a.view-all-earnings").click(function(){
            framework.browser.navigate({
                'url': PP.substitute("{host}/account/earnings"),
                'tabId': framework.browser.NEWTAB
            });            
        })

        $( ".action-register" ).click(function() {
          $( ".login-content" ).hide();
          $( ".forgot-content" ).hide();
          $( ".register-content" ).show();
          return false;

        });

        $( ".action-login" ).click(function() {
          $( ".register-content" ).hide();
          $( ".forgot-content" ).hide();
          $( ".login-content" ).show();
          return false;

        });

        $( ".action-forgot" ).click(function() {
          $('form#forgot input[type=text]').val($('form#login input[type=text]').val());
          $( ".register-content" ).hide();
          $( ".login-content" ).hide();
          $( ".forgot-content" ).show();
          return false;

        });


        $( "#show-password" ).click(function() {
            if($('#password')[0].type == 'text'){
                $('#password')[0].type = 'password';
            }
            else{
                $('#password')[0].type = 'text';
            }
          
          return false;
        });


        $("a.view-all-deals").click(function(){
            framework.browser.navigate({
                'url': PP.substitute("{host}/coupons"),
                'tabId': framework.browser.NEWTAB
            });            
        })

        $("a.view-merchant-deals").click(function(){
            framework.browser.navigate({
                'url': PP.substitute("{host}/coupons/{short_name}",current_merchant),
                'tabId': framework.browser.NEWTAB
            });            
        })


        $("header ul > li a").on('click', function() {

            var id = $(this).attr("data-target");            

            $("header ul > li").removeClass("active");
            $(this).parent().addClass("active");

            
            $("section").removeClass("show");
            $("section#"+ id).addClass("show");
            return false;
        });

        $("form#login").submit(function(){
            var email= $('form#login input[type=text]').val();
            var pass= $('form#login input[type=password]').val();

            //Clear error message if any
            $("form#login button[type=submit]").parent().find("p").remove();

            //Try to login
            PP.login(email,pass,function(res){
                if (res.ok){
                    setAccount();
                    $( ".section-slide" ).slideToggle( );
                }
                else{                    
                    $("form#login button[type=submit]").before($("<p>").html(res.msg));
                }
            });
            return false;
        })

        $("form#forgot").submit(function(){
            var email= $('form#forgot input[type=text]').val();

            //Clear error message if any
            $("form#forgot button[type=submit]").parent().find("p").remove();

            //Send reminder
            PP.forgotPassword(email,function(res){
                $("form#forgot button[type=submit]").before($("<p>").html(res.msg));
            });
            return false;
        })


        $("form#register").submit(function(){
            var email= $('form#register input[type=text]').val();
            var pass= $('form#register input[type=password]').val();

            //Clear error message if any
            $("form#register button[type=submit]").parent().find("p").remove();

            //Try to register
            PP.signup(email,pass,function(res){
                if (res.ok){
                    setAccount();
                    $( ".section-slide" ).slideToggle( );
                }
                else{                    
                    $("form#register button[type=submit]").before($("<p>").html(res.msg));
                }
            });
            return false;
        })


        $("a.how-it-works").click(function(){
                framework.browser.navigate({
                    'url': PP.substitute("{host}/about-cashback"),
                    'tabId': framework.browser.NEWTAB
                });                                        
        })
        $("a.account").click(function(){
            framework.browser.navigate({
                'url': PP.substitute("{host}/account"),
                'tabId': framework.browser.NEWTAB
            });                                        
        })
        $("a.eula").click(function(){
            framework.browser.navigate({
                'url': PP.substitute("{host}/eula"),
                'tabId': framework.browser.NEWTAB
            });                                        
        })

        $("a.privacy").click(function(){
            framework.browser.navigate({
                'url': PP.substitute("{host}/privacy"),
                'tabId': framework.browser.NEWTAB
            });                                        
        })

        $("a.twitter-btn").click(function(){
            if (current_account){
                framework.browser.navigate({
                    'url': "https://twitter.com/intent/tweet?url="+encodeURIComponent(current_account['reflink'])+"&text="+encodeURIComponent(current_account['refmsg']),
                    'tabId': framework.browser.NEWTAB
                });                                        
            }
        })
    }

    function setActive(){
        $("#coupons").addClass("active");
        current_merchant.activated=true;

    }

    function setInactive(){
        $("#coupons").removeClass("active");
    }

    function setMerchant(){

    	PP.getMerchant(bg.currentUrl, bg.currentTab,  function(merchant) {
            merchant_checked = true;
            current_merchant = merchant;
    		if (merchant) {
                $(".requires-no-merchant").hide();

    			if (merchant.activated) {
                    setActive();
                }
                else{
                    setInactive();
                    var activate_btn=$("#coupons .section-header .activate-cashback")                    
                    $("#coupons .section-header .activate-cashback").html('Activating! <i class="fa fa-circle-o-notch fa-spin"></i>');
                    PP.activate(merchant,function(){
                        //clearInterval(activationInterval);
                        setActive();
                    });

                }

                $("#coupons .section-header img")
                    .attr("src","https://d2umvgb8hls1bt.cloudfront.net/uploads/stores/"+merchant.image150x90_filename)
                    .attr("alt",merchant.store_name);
                $("#coupons .section-header.activate h3.title").html(merchant.activate_message);
                if (merchant.cashbk_pct>0){
                    $("#coupons .section-header.active-message h3.message").html("Your +" +merchant.cashback_print+" Cashback is Activated!");    
                }
                else{
                    $("#coupons .section-header.active-message h3.message").html("Checkout these awesome deals we found for you!");
                }
                
                $("#coupons .section-header .activate-cashback").click(function(){
                    var activate_btn=$(this);
                    activate_btn.html('Activating! <i class="fa fa-circle-o-notch fa-spin"></i>');
                    PP.activate(merchant,function(){
                        //clearInterval(activationInterval);
                        setActive();
                    });
                });
                
                //Get and render merchant coupons and sales.             
                PP.getDeals({merchant:merchant, items:dealsItems}, function(deals_data) {
                    //If no coupons/deals for this merchant, get top coupons/deals from any merchant
                    var deals = deals_data.deals;
                    if (!deals || deals.length<=0) {
                        PP.getDeals({merchant:null, items:dealsItems}, function(deals) {
                            renderMerchantDeals(deals);
                            setDefaultTab();                            
                        });
                    } else {                

                        renderMerchantDeals(deals);        
                        setDefaultTab();
                    }
                });

                
    		} else {
                //Hide coupons
                $(".requires-merchant").hide();

                PP.getDeals({merchant:null, items:dealsItems},function(deals_data){
                    renderTopDeals(deals_data.deals);

                    //selectTab("deals");
                });
            }

    	});
    }

    function selectTab(tab){
        $("header ul > li").removeClass("active");
        $("section").removeClass("show");

        $("header ul > li#sel_"+tab).addClass("active");            
        $("section#"+tab).addClass("show");                
    }

    function renderTopDeals(deals){
        $("#deals .coupon").remove();
        var template = $("#templates div.coupon-template").html();

        for (d in deals){
            var deal_data  = deals[d];            
            var deal = template;
            deal_data["is_merchant"]=0;

            if (deal_data["coupon"]!=""){
                deal_data["coupon_class"]="coupon-code";
            }
            else{
                deal_data["coupon_class"]="";
            }

            for (field in deal_data){
               deal= replaceAll("{"+field+"}", deal_data[field], deal);
            }            
            
            $("#deals .section-list-scroll").append(deal);
        }
        prepareClipboardCopy();
    }

    function renderMerchantDeals(deals){
        $("#coupons .coupon").remove();
        var template = $("#templates div.coupon-template").html();

        for (d in deals){
            var deal_data  = deals[d];            
            var deal = template;
            deal_data["is_merchant"]=1;

            if (deal_data["coupon"]!=""){
                deal_data["coupon_class"]="coupon-code";
            }
            else{
                deal_data["coupon_class"]="";
            }

            for (field in deal_data){
                deal= replaceAll("{"+field+"}", deal_data[field], deal);
            }

            $("#coupons .section-list-scroll").append(deal);
        }
        prepareClipboardCopy();

    }

    function prepareClipboardCopy(){



        return;
        ZeroClipboard.config( { swfPath: "https://d195uvwku2xa4f.cloudfront.net/zeroclipboard/ZeroClipboard.swf" } );
        client = new ZeroClipboard( $(".coupon-code") );
      client.on( 'error', function(event) {
        console.log( 'ZeroClipboard error of type "' + event.name + '": ' + event.message );
        //ZeroClipboard.destroy();
      } );        
        client.on( "ready", function( readyEvent ) {
             alert( "ZeroClipboard SWF is ready!" );
            client.on( 'copy', function(event) {
              event.clipboardData.setData('text/plain', $(event.target).attr("data-coupon_code"));
            } );
            client.on( "aftercopy", function( event ) {
                // `this` === `client`
                // `event.target` === the element that was clicked
                console.log("Copied text to clipboard: " + event.data["text/plain"] );
            } );
        } );    

    }

    function setAccount(){        
    	PP.getUserAccount(function(account) {
            current_account = account;
            account_checked = true;
    		if(account && typeof account['email']) {
                $("a.view-account").html("View Account");

                $("#coupons .section-header.active-message h3.title").html("Congratulations " +account['firstname']);

                $("a.fb-btn").attr("href","https://www.facebook.com/sharer/sharer.php?u="+encodeURIComponent(account['reflink']) );
                $("a.twitter-btn").attr("href", "https://twitter.com/intent/tweet?url="+encodeURIComponent(account['reflink'])+"&text="+encodeURIComponent(account['refmsg']));
                $("a.mail-btn").attr("href","mailto:?subject=Hey, you have to check this out&body="+encodeURIComponent(account['refmsg']) );

                $(".requires-account").removeClass("hide");

                $("#account .section-header .number p").html("<span>$</span>"+account['total_earnings']);
                $('#earnings_tbody').empty();
                if(account.transactions.length) {
                    for (var i=0;i<account.transactions.length;i++){
                        var trans=account.transactions[i];
                        $('#earnings_tbody').append(
                            $("<tr>").append($("<td>").html(trans.store_name))
                            .append($("<td>").html(trans.date))
                            .append($("<td>").html(trans.attribution_amount))
                        );                        
                    }
                    $('#earnings-table-container').show();
                    $('#no-earnings').hide();                                            
                }
                else{
                    $('#earnings-table-container').hide();
                    $('#no-earnings').show();
                }     

                setDefaultTab();                   
    		} 
            else{
                PP.getAppEarnings(function(account){

                    current_earnings = account;
                    account_checked = true;

                    $("a.view-account").html("Claim Earnings");
                    
                    $("#coupons .section-header.active-message h3.title").html("Congratulations" );

                    $("a.fb-btn").attr("href","https://www.facebook.com/sharer/sharer.php?u="+encodeURIComponent(account['reflink']) );
                    $("a.twitter-btn").attr("href", "https://twitter.com/intent/tweet?url="+encodeURIComponent(account['reflink'])+"&text="+encodeURIComponent(account['refmsg']));
                    $("a.mail-btn").attr("href","mailto:?subject=Hey, you have to check this out&body="+encodeURIComponent(account['refmsg']) );


                    $("#account .section-header .number p").html("<span>$</span>"+account['total_earnings']);
                    $('#earnings_tbody').empty();
                    if(account.transactions.length) {
                        for (var i=0;i<account.transactions.length;i++){
                            var trans=account.transactions[i];
                            $('#earnings_tbody').append(
                                $("<tr>").append($("<td>").html(trans.store_name))
                                .append($("<td>").html(trans.date))
                                .append($("<td>").html(trans.attribution_amount))
                            );                        
                        }
                        $('#earnings-table-container').show();
                        $('#no-earnings').hide();                        
                    } else {
                        $('#earnings-table-container').hide();
                        $('#no-earnings').show();
                    }

                    setDefaultTab();

                });
            }
    	});
    }

    function setDefaultTab(){
        if ( merchant_checked && account_checked){
            if (current_account){
                if (current_account.total_earnings>0){
                    selectTab("account");
                    return;
                }
            }
            if (current_earnings){
                if (current_earnings.total_earnings>0){
                    selectTab("account");
                    return;
                }
            }
            if (current_merchant){
                 selectTab("coupons");
                 return;
            }
        }
    }


    function checkNotificationsDisabled(){
        framework.extension.getItem('notificationsDisabled', function(state) {
            $('[name="notifications"][value="'+(!!state?1:0)+'"]').attr('checked', true);
            $('[name="notifications"]').change(function (event) {
                framework.extension.setItem('notificationsDisabled', parseInt(event.target.value));
            });
        });        
    }

    function replaceAll(find, replace, str) {
        return str.replace(new RegExp(find, 'g'), replace);
    }    

    init();

}

$(function() {
	if (typeof framework != 'undefined') {
		CFPopup();
	} else {
		window.setTimeout(CFPopup, 50);
	}
});



window.setTimeout(function() {
	function search(){
		framework.browser.navigate({
			'url': PP.substitute(bg.urlSearch, {
				'keywords': $('#search-terms').val()
			})
		});
		window.close();
	}
	$('#search-terms').autocomplete({
		'minLength': 3,
		'position': { my : 'center bottom', at: 'center top' },
		'source': function( request, response ) {
			var size = 0;
			var resp = [];
			$.each(PP.merchants, function(i, domain){
				if(size > 10) return false;
				resp = resp.concat($.map(domain, function(merch){
					if (merch.store_name.toLowerCase().indexOf(request.term.toLowerCase()) >= 0) {
						size ++;
						return {
							'value': merch.store_name
						}
					}
					return null;
				}));
			});
			response(resp);
		}
	})
	.keypress(function(aEvent){
		if (aEvent.which == '13') {
			search();
		}
	})
	/*.data('ui-autocomplete')._renderItem = function( ul, item ) {
		return $('<li class="ui-menu-item" role="presentation">')
			.append('<a><span class="search-suggest-name">' + item.value + '</span></a>')
			.appendTo( ul );
	};
	$('.search-btn').click(search);*/
}, 600);
