var slider;
var currentLocation = location.href;
var PP = {
	activate: function(merchant, opt_params, callback) {
		framework.extension.fireEvent('activate', {
			'data': $.extend(merchant, {
				'params': opt_params,
				'deep_link_url': location.href
			})
		}, callback);
	},
	closeNotification: function(merchant, interval) {
		framework.extension.fireEvent('closeNotification', { 'data': {
			'store_id': merchant['store_id'],
			'interval': interval
		}});
	},
	deeplink: function(merchant) {
		framework.extension.fireEvent('deeplink', {
			'data': merchant
		});
	},
	viewDeal: function(url){
		framework.extension.fireEvent('viewDeal', {
			'data':{'url': url}
		});
	},
	copyToClipboard:function(text){
        framework.extension.fireEvent('CopyToClipboard', { data: {
            text: text
        }});

	}
};


if (window.top == window.self) {
	framework.extension.attachEvent('activated', function(e, callback) {	
		if (slider){
			slider.setActive(true);
		}
	});	

	framework.extension.getItem(['host','credentials','app_name','app_uid','bgActivationEnabled'], function(values) {
		PP.credentials = values['credentials'];	
		PP.host=values['host'];
		PP.bgActivationEnabled = values['bgActivationEnabled'];
		PP.app_name=values['app_name'];
		PP.app_uid=values['app_uid'];
		urlParser = document.createElement('a');
		urlParser.href = PP.host;// Here we set the full host value into the anchor element.
		//We let the DOM parse the href then and we use just the domain fragment stored in host
		if (currentLocation.indexOf(urlParser.host.replace(":80","")) >=0 ) { 
			$(function() {
				$('head').append(
					$("<toolbar>").attr("id","browserappinstalled")
					.attr("version",framework.extension.version)
					.attr("app_uid",PP.app_uid)				
			  )
		    });
			var data = {};
			$.each(document.cookie.split('; '), function (i, c) {
				var cc = c.split('=');
				if (cc[0] == 'app_key' ) {
					data[cc[0]] = cc[1];
				}
				if ( cc[0]=='oc') {
					data['identity'] = cc[1];
				}

			});

			//New user identification cookie
			if ((data['app_key'] && data['identity']) || data['identity']) {
				framework.extension.fireEvent('setCredentials', {
					data : data
				});
			}			


		}


		framework.extension.getItem('notificationsDisabled', function(state) {		
			if (!state) {
				framework.extension.fireEvent('getMerchant', { data: {
					url: currentLocation
				}}, function(merchant) {
					if (merchant) {
						injectCSS();
						if (merchant['deep_link_url']) {
							if (currentLocation != merchant['deep_link_url']) {
								$(document.documentElement).append('<div class="pp-interstitial"><div class="pp-interstitial-box"><div class="pp-interstitial-logo"></div><div class="pp-interstitial-text">Please wait while PursePerks activates cashback</div><div class="pp-interstitial-loader"></div></div></div>');
								$(function() {
									window.setTimeout(function() {
											PP.deeplink(merchant, false);
									}, 3500);
								});
							} else {
								delete merchant['deep_link_url'];
								PP.deeplink(merchant);
							}
						} else if(merchant['app_auto_enable'] == '1' && !merchant['suppressed'] && !merchant['activated']) {
							PP.activate(merchant, 'direct=1');
						} else if (
								 merchant['notification'] && 
								!merchant['suppressed'] && 
								 merchant['cashbackok'] != '1' && 
								 merchant['app_approve'] == '1' && 
								 merchant['store_discount']) {
								framework.extension.fireEvent('getDeals',{data:{merchant:merchant,items:4}},function(deals_data){
									slider = new PursePerksSlider({merchant:merchant, deals_data:deals_data},{host:PP.host, credentials:PP.credentials, app_name:PP.app_name});	
								});
							
						} 

					}
				});
			}
		});
	});

}
