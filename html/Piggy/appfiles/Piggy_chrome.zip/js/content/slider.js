function PursePerksSlider(data, opt_options) {

	var merchant = data.merchant;
	var deals    = data.deals_data.deals;
	var total_merchant_deals    = (data.deals_data.total>0) ? data.deals_data.total : "";
	var injection = this;
	var host;
	var bgActivationEnabled;
	var credentials;
	var absoluteElemetns = [];
	var blink_interval;
	var options = $.extend({
		'app_name': "",
		'interval': 5000,		//-- interval in ms to show slider
		'quirks': ('\v'=='v') && (document.compatMode == 'BackCompat'),
		'message_active':"Cashback Active !",
		'message_activate':"Click to view coupons, rebates & cash back!",
		'close_interval': 15 //Time to stay closed in minutes
	}, opt_options);

	if (options['host']) {
		host=options['host'];
	}

	if (options['credentials']){
		credentials = options['credentials'];
	}


	var header_message 	= "";
	if (merchant['activated']){
		header_message  = "You are getting now "+merchant['cashback_print']+" Cash Back.";
	}
	else{
		header_message  = options['message_activate'];
	}


	function activate(btn,minimize,extra_params) {
		if (btn){
			btn.html("ACTIVATING");

			var i=0;
			blink_interval = setInterval(function(){
				btn.css("opacity",0.3+0.7*(Math.sin(i++/5)));
			},20);						
		}

		if (!extra_params) extra_params=''; //Extraparams sent as string, like 'ref2=sc' indicates slider closed

		PP.activate(merchant,extra_params,function(){	
			injection.setActive(minimize);
		});
	}

	injection.setActive = function(minimize){
		if (merchant['activated']) return;

		merchant['activated'] = true;
		if (blink_interval){
			clearInterval(blink_interval);	
		}
		
		//Hide on activate only if tab was already expanded and clicked on a coupon/deal
		if (minimize){
			window.setTimeout(function() {
				injection.minimize();
			}, 3000)				
		}

		$(".cof-lowertab-action").addClass("cof-active");
		$(".cof-lowertab-action p.cof-header-message").html("You are getting now "+merchant['cashback_print']+" Cash Back.").css("opacity",1);
	}

	function sleep(){
		PP.closeNotification(merchant, options.close_interval);
		
	}

	function getStyle(el, cssprop){
		if (el.currentStyle) {
			return el.currentStyle[cssprop];
		} else if (document.defaultView && document.defaultView.getComputedStyle) {
			var style = document.defaultView.getComputedStyle(el, "");
			return style?style[cssprop]:null;
		} else if (el.style) {
			return el.style[cssprop];
		}
	}



	//First lets build the coupons and deals DOM into a content variable, so we can append them into the content container with a single line below 
	var content = $('<div class="cof-lowertab-content">');

	//In cases where there's no way to do background activation, the header can't be used for activation,
	//it can only be use to maximize the toolbar. We add this button for explisit activation on these cases
	if (!PP.bgActivationEnabled && !merchant['activated']){
		content.append(
			$("<div>").addClass("cof-full-btn")
			.append(
				$("<a>").attr("href","javascript:void(0)")
				.addClass("cof-btn cof-btn-activate cof-btn-small")
				.html("Activate")
			)
		)
	}

	for (d in deals){
		var deal=deals[d];
		
		if (deal['coupon']!=""){
		    var button = $("<div>").addClass("cof-input-group")
                        .append($("<div>").addClass("cof-input-group-addon").html("Copy Code"))
                        .append($("<input>").addClass("cof-copycode").attr("id","cof-input-coupon-"+deal['coupon']).attr("type","text").val(deal['coupon']))
                        .attr("data-coupon",deal['coupon']); 
                        
			button.click(function(){
				var coupon_code=$(this).data("coupon");
	            if (framework.browser.name=="Safari"){
	            	$(this).find("em.cof-msg").remove();
	                $(this).append($("<em>").addClass("cof-msg").html("Hit ctrl-c to copy to clipboard"));                    
	                if (!merchant['activated']){	
	                	if (PP.bgActivationEnabled){
	                		activate(null,false,'ref2=scp');	
	                	}                		                	 
	                }
	                $(this).find("input").focus().select();
	            }
				else{
					PP.copyToClipboard(coupon_code);
					$(this).find("em.cof-msg").remove();
	                $(this).append($("<em>").addClass("cof-msg").html("Code copied to clipboard."));
	                
					if (!merchant['activated']){
						if (PP.bgActivationEnabled){
	                		activate(null,true,'ref2=scp');					
	                	}
	                }
				}				
			});
		}else{
			var button = $('<a class="cof-btn cof-btn-sec" href="javascript:void(0)">').html(deal['button_text']).attr("data-coupon",deal['coupon']); 
			button.click(function(){
				var url = deal['link'];
				PP.viewDeal(url+'&ref1=ba&ref2=svd&ref3=Cof');
			});
		}

		content.append($('<div class="cof-lowertab-coupon">').addClass("cof-coupon-"+(1+parseInt(d)))
			.append($('<h2>').html(deal['name']))
			.append(button)
			.append($('<em>').addClass("cof-"+deal['expires']).html("Exp.&nbsp"+deal['expire_date']))
		);		

	}
	if (data.deals_data.total>0){
		var link_msg="View all "+total_merchant_deals+" deals";
	}
	else{
		var link_msg="See full details";
	}

	content.append(
		$("<a>").attr("href",host+"/coupons/"+merchant['short_name'])
			.attr("target","_blank")
			.html(link_msg)
	);


	injection.div = $('<div class="cof-lowertab">')
		.append($('<div class="cof-lowertab-header">')
			.append($('<div id="tab-expand">')
				.append('<div class="cof-img-arrow">')
				.append($('<h2>')
					.append(merchant['store_name']+"'s")
					.append('<br>')
					.append($('<span>').html(total_merchant_deals + ' Deals'))
				)
				.append('<a href="javascript:void(0)" class="cof-lowertab-close">close</a>')
			)
		)
		.append($('<div class="cof-lowertab-action">')
			.addClass(merchant['activated']?'cof-active':'')
			.append($('<a  href="javascript:void(0)" class="cof-btn">')
				.append("+"+merchant['cashback_print'])
				.append("<br>")
				.append("<span>Cash Back</span>")
			)
			.append($('<p class="header-message">'+header_message+'</p>'))
            .append($('<p>powered by <span class="cof-logo" ></span></p>').attr("alt",options.app_name))
		)
		.append(content)
		.append(
			$('<div class="cof-lowertab-footer">').append(
				$('<a>').attr("href",host+"/coupons/"+merchant['short_name']+"#terms").attr("target","_blank").html("View cashback terms")
			).append(
				$('<a>').attr("href",host+"/terms").attr("target","_blank").html("What's this?")
			)
		);



	//-- hide slider after n seconds
	/*
	if (merchant['activated']) {		
		window.setTimeout(function() {
			injection.minimize();
		}, 7000)
	}
	*/
	
	injection.show = function() {


		injection.div.appendTo(document.body);
		var height=injection.div.height();
		console.log(merchant['first_visit']);
		if ( (! merchant['activated']) && merchant['first_visit']){
			injection.div.animate(
				{ 
			  		bottom:180-height
			    }, // Animating Tab
			    {
			        duration: 1000, // how fast we are animating
			        easing: 'easeOutBounce' // the type of easing
		    	}
		    );
		}
		else{
			injection.minimize();
		}

		/*
		$(".lowertab-action").click(function(){
			if (! merchant['activated']){
				activate($('.lowertab-action p.header-message'),false);	
			}

		});
		*/

		$(".cof-lowertab-header, .cof-lowertab-action").on('click', function(){				
			if($(".cof-lowertab").hasClass("cof-expanded")){
				injection.minimize();
			}
			else{
				if (! merchant['activated']){
					if(PP.bgActivationEnabled){
						activate($('.cof-lowertab-action p.cof-header-message'),false,'ref2=so');		
					}					
				}				
				injection.maximize();
			}
			
			return false;
		});


		//If cashback button is clicked, activate no matter what
		$(".cof-full-btn").on('click', function(){	
			//If no bg activation possible, use the button as an activate action, which will navigate out	
			if (! merchant['activated']){
				activate(null,false,'ref2=sa');						
			}	
			return false;
		});


		$("a.cof-lowertab-close").click(function(){
			if (PP.bgActivationEnabled){
				if (! merchant['activated']){
					activate(null,false,"ref2=sc");		
				}
			}
			
			sleep();
			$(".cof-lowertab").flyOffPage({
			    duration: 500, // 400 milliseconds (0.4 seconds)
			    direction:"topRight",
			    tween: {
			        opacity: 0,
			        height:0,
			        width:0
			    }
			});	
			setTimeout(function(){injection.hide();},500);		
			
			return false;
		});

	};

	injection.minimize = function(){
		var height=injection.div.height();
		var headerHeight = $(".cof-lowertab .cof-lowertab-header").outerHeight();
		$(".cof-lowertab").animate({ 
			bottom:headerHeight-height
		  }, // Animating Tab
		  {
		      duration: 1000, // how fast we are animating
		      easing: 'easeOutBounce', // the type of easing
		      complete: function() { // the callback
		         $("#tab-expand img").attr('src','images/icon-arrowup.png');
		         $(".cof-lowertab").removeClass("cof-expanded");
		      }
		  });
	}

	injection.maximize = function(){		
		$(".cof-lowertab").animate({ 
  				bottom:0
		    }, // Animating Tab
		    {
		        duration: 1000, // how fast we are animating
		        easing: 'easeOutBounce', // the type of easing
		        complete: function() { // the callback
		           $("#tab-expand img").attr('src','images/icon-arrowdown.png');
		           $(".cof-lowertab").addClass("cof-expanded");
		        }
	    });

	}


	injection.hide = function(callback) {
		var height=injection.div.height();
		injection.div.animate({
			'bottom': -height
		}, {
			'duration': 350,
			'easing': 'easeInOutQuint',
			'complete': function () {
				injection.div.remove();
			}
		});
	};

	$(function(){
		setTimeout(function(){
			injection.show();		
		},1); //Test with no delay					
	});

	return injection;
}

