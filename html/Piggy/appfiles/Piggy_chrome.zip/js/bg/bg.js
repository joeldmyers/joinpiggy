﻿'use strict';
if (typeof host == "undefined"){


var DEBUG = true;
var host = "http://www.joinpiggy.com"; //HOST will be replaced by rake script
var app_name = "Piggy"; //APP_NAME will be replaced by rake script
var urlParser = document.createElement('a');
urlParser.href = host;// Here we set the full host value into the anchor element.
//We let the DOM parse the href then and we use just the domain fragment stored in host
var host_domain = urlParser.host.replace(":80",""); //Remove port in case browser added it (at least IE does that)

var bgActivationEnabled = true; 


var urlHomepage 		= host;
var urlAfterInstall     = host + '/thankyou';
var urlInstall    		= host + '/api/install?token=12345&v={version}';
var urlLogin    		= host + '/api/login?token=12345';
var urlForgotPassword   = host + '/api/forgot?token=12345';
var urlSignup    		= host + '/api/signup?token=12345';
var urlMerchants 		= host + '/api/newstores?token=12345';
var urlAccount 			= host + '/api/account?token=12345&app_key={app_key}';
var urlAppEarnings		= host + '/api/appearnings?token=12345';
var urlOffers 			= host + '/api/offers?token=12345';
var urlDeals 			= host + '/api/topdeals?token=12345';
var urlSearch 			= host + '/search?keywords={keywords}';
var urlActivation 	    = host + '/int?s={store_id}&o={offer_id}&ref1=ba&ref3=Cof&appskip=1&appuid={userid}&deeplink={url}&name={firstname}&direct=1'
var urlFavorite         = host + '/api/addfavoritewidget?user_id={userid}&store_id={store_id}&token=12345';

var addonTimeouts = {};
var paidLinkTimeouts = {};
var TIMEOUT_INTERVAL = 60*1000; // once a minute
var UPDATE_INTERVAL = 60*60*1000; // once an hour
var paidLinksWCs = ["*commission-junction.com*","*qksrv.net*","*jdoqocy.com*","*tkqlhce.com*","*kqzyfj.com*","*dpbolvw.net*","*anrdoezrs.net*","*google.com\/aclk*","*dpbolvw.net*","*linksynergy.com*","*afsrc=1*","*affiliate.buy.com*","*affiliate.rakuten.com*"];
var currentUrl = '';
var currentTab = '';
var PP;
//-------------------------------------------------------------------
//-- Event Listeners
//--
//--
//-------------------------------------------------------------------
//-- Browser Events
//--
//-------------------------------------------------------------------
//-- We need to check every page user visited to accordingly procced
//-- merchant state. There are two types of events may leads to change 
//-- current page - DocumentCompletes, meand user gets on new page;
//-- and TabChanged,means user switch current actibe tab; Both events
//-- are handled in the same way and pass similar event object in
//-- their handler so we can use one handler for both Events;

framework.browser.attachEvent(framework.browser.DOCUMENTCOMPLETE, handlePage);
framework.browser.attachEvent(framework.browser.TABCHANGED, handlePage);

framework.browser.attachEvent(framework.browser.TABCLOSED, function(e) {
	if (PP && PP.tabs[e['tabId']]) {
		delete PP.tabs[e['tabId']];
	}
});


//-------------------------------------------------------------------
//-- To handle affiliate links, framework outbound links and drop 
//-- merchant activation we need to catch BeforeNavigate event
//-- which actually inlcudes BefreRedirect Event to coorectly proceed
//-- entire redirection chain;

framework.browser.attachEvent('BeforeNavigate', function(e){
	//-- We don't need to do anything until user is no signed in;
	if(PP && e['url']){

		//------------------------------------------------------------------------
		//-- Check if current URL is outbound PursePerks link by applying following
		//-- regular expression to it;
		var exp = new RegExp("^[^?]*"+host_domain.replace(/\./g,"\\.")+"\\/int\\?s=\\d");
		if (exp.test(e['url'])) {
			PP.log('Activation Link Detected: ' , e['url'], e['tabId']);

			//-- If there's outbound link let's initiate PursePerks Timeout which will 
			//-- let us know when user lands of merchant page that he/she went through
			//-- PursePerks websites therefore merchant is activated and we have to turn 
			//-- extension into green state; We set this timer for 'TIMEOUT_INTERVAL'
			//-- seconds which is actually 60seconds at this point;
			if(addonTimeouts[e['tabId']]) {
				window.clearTimeout(addonTimeouts[e['tabId']]);
			}

			addonTimeouts[e['tabId']] = window.setTimeout(function(){
				delete addonTimeouts[e['tabId']];
			}, TIMEOUT_INTERVAL);
		} 

		//------------------------------------------------------------------------
		//-- If it's not an PursePerks link we have to check other options: other affiliate
		//-- networks link and other merchants;
		else {

			//-- We should only check for affiliate links in case of user didn't come
			//-- through the PursePerks outbound links so addonTimout for appropriate tab
			//-- should not exists
			if(!addonTimeouts[e['tabId']] && PP.paidLinks){
				//-- We have set of links to check so let's check it one by one
				$.each(PP.paidLinks, function(i, domain){
					if(e['url'] && e['url'].search(domain) >= 0){
						PP.log('Paid Link Detected: ' , e['url'], e['tabId']);

						//-- If we found affiliate link we have to set another timer named 
						//-- 'paidLinkTimeout'; It'll let us know that we shouldn't activate
						//-- merchant followed by this redirection chain but proceed it in a
						//-- different way named 'suppression'
						paidLinkTimeouts[e['tabId']] = window.setTimeout(function(){
							delete paidLinkTimeouts[e['tabId']];
						}, TIMEOUT_INTERVAL);
						return false;
					}
				});
			}


			//-- And the last thing we have to check during BeforeNavigate is if
			//-- user has landed on new merchant so we need to drop prev merchant activation
			//-- Also we don't need to check this for subframes cuz we suppose user
			//-- lends on merchant in main frame that's whe ther's check for e.frameId==0;
			if(!paidLinkTimeouts[e['tabId']]) {
				//-- Get store is the method which returns merchant object by URL; It doesn't contain
				//-- any info about activation etc cuz these values are tab-related
				PP.getStore(e['url'], function(merchant){
					if(merchant) {
						//-- So if current merchant is not the same as stored in tar-related array
						//-- let's purge prev merchant actvation; Actually it means we just drop 
						//-- merchant activation when user leaves merchant site;
						if(PP.tabs[e['tabId']] && PP.tabs[e['tabId']]['store_id'] != merchant['store_id']) {
							delete PP.tabs[e['tabId']];
						}

						//-- As far as we detect merchant let's set activation status if
						//-- not defined yet;						
						PP.tabs[e['tabId']] = PP.check(merchant);
					}
				});
			}
		}
	}
});

framework.extension.attachEvent('getDeals', function(e, callback) {	
		PP.getDeals(e['data'], function(deals) {
			callback(deals);
		});	
});

framework.extension.attachEvent('getMerchant', function(e, callback) {
	if(e['data']['url'].indexOf('http') == 0 && e['data']['url'].indexOf(host_domain) < 0 && PP){
		PP.getMerchant(e['data']['url'], e['tabId']||0, function(merchant, domain) {
			//-- if user has leaved merchant site let's drop merchant activation
			if(!merchant && PP.tabs[e['tabId']]) {
				delete PP.tabs[e['tabId']];
			}

			if(merchant && e['tabId']) {

				if (!PP.tabs[e['tabId']]) {
					PP.tabs[e['tabId']] = {
						'store_id': merchant['store_id']
					}
				}				
				
				
				PP.tabs[e['tabId']]['activated'] =  PP.check(merchant).activated || !!addonTimeouts[e['tabId']];
				if (!!addonTimeouts[e['tabId']]) {
					delete addonTimeouts[e['tabId']];
				}
				
				if( paidLinkTimeouts[e['tabId']] || (PP.tabs[e['tabId']]['suppressed'] && PP.tabs[e['tabId']]['store_id'] == merchant['store_id'])){
					if(paidLinkTimeouts[e['tabId']]) {
						delete paidLinkTimeouts[e['tabId']];
					}
					$.extend(PP.tabs[e['tabId']], {
						'store_id': merchant['store_id'],
						'activated': false,
						'suppressed': true
					});
				}
				var res = $.extend({}, merchant, PP.tabs[e['tabId']]);
				PP.updateIcon(res);
				if ( PP.visited[merchant['store_id']] ){
					res.first_visit = false;
				}
				else{
					res.first_visit = true;
					PP.visited[merchant['store_id']] = true;
				}
				
				callback(res);
			} else {
				if (merchant){
					if ( PP.visited[merchant['store_id']] ){
						merchant.first_visit = false;
					}
					else{
						merchant.first_visit = true;
						PP.visited[merchant['store_id']] = true;
					}					
				}
				callback(merchant);
			}
		});
	}
});


//-- This is hanlder for SERP links; We just need to check each URL 
//-- is it merchant or not; And if it is, we return back its params;
framework.extension.attachEvent('getStore', function(e, callback) {
	if(PP) {
		PP.getStore(e['data']['url'], function(merchant){
			if(merchant){
				callback(merchant);
			} else {
				callback(null);
			}
		});
	} else {
		callback(null);
	}
});

framework.extension.attachEvent('activate', function(e, callback) {
	PP.log('Activate from content', e['url']);
	PP.activate(e['data'],callback);
	if(callback){
		//callback();
	}
});

framework.extension.attachEvent('viewDeal', function(e, callback) {
	PP.log('View deal', e['url']);
    framework.browser.navigate({	            	
        'url': PP.substitute(e['data']['url'])
    }); 			
	if(callback){
		callback();
	}
});

framework.extension.attachEvent('slider', function(e, callback) {
	if (PP.tabs[e.tabId] && e.data.activated) {
		PP.tabs[e.tabId].activatedSlider = true;
	}
});
framework.extension.attachEvent('deeplink', function(e, callback) {
	PP.deeplink(e['data'], e['tabId']);
});

framework.extension.attachEvent('closeNotification', function(e) {
	PP.log('closeNotification', e['data']);
	PP.disableNotification(e['data']['store_id'], e['data']['interval']);
	// $.extend(PP.tabs[e['tabId']], {
	// 	'notification': false
	// });
});

framework.extension.attachEvent('setCredentials', function(e) {
	PP.log('set credentials', e['data']);
	if (!PP['credentials'] || PP['credentials']['identity'] != e['data']['identity'] || PP['credentials']['app_key'] != e['data']['app_key']) {
		framework.extension.setItem('credentials', e['data']);
		PP.reset(e['data']);
	}
});


//*****************************
//Initialize 
framework.extension.getItem('credentials' , function(credentials) {
	PP  = new APIConnector(credentials);	
});

framework.extension.attachEvent('CopyToClipboard', function(e) {
	// IE
	var eventData = (typeof e.data === "undefined") ? e : e.data;
	if (window.clipboardData){
		window.clipboardData.setData('Text', eventData.text);
	} 
	// Firefox
	else if (window.netscape){
			var gClipboardHelper = Components.classes["@mozilla.org/widget/clipboardhelper;1"].
				getService(Components.interfaces.nsIClipboardHelper);
			gClipboardHelper.copyString(eventData.text);
	} 
	// Chrome
	else if (!window.safari){
		$("<input />").val(eventData.text).appendTo(document.body).get(0).select();
		document.execCommand("copy", false, null);
	}
	// Safari is individual - it doesn't support clipboard copying, so we use flash to do that.
});


window.setTimeout(function() {
	framework.ui.button.setPopup({
		'url': 'popup/widget.html',
		'width': 492,
		'height': 412
	});
}, 500);

}
function APIConnector(credentials){

	var self = this;
	var icon = new Icon();
	var update_timeout; 
	self.app_uid = null;
	self.account = null;
	self.paidLinks = [];
	self.merchants = {};
	self.notifications = {};
	self.offers = {};
	self.deals = {};
	self.tabs = {};
	self.visited = {};
	self.debug = DEBUG;

	if (credentials){
		self.credentials = credentials;	
	}
	
	


	$.support.cors = true;

	function substitute(str, params) {
		str = str
			.replace(/\{url\}/g, encodeURIComponent(currentUrl))
			.replace(/\{host\}/g, host);

		if (self.credentials) {
			if (self.credentials['app_key']){
				str = str.replace(/\{app_key\}/g, self.credentials['app_key'])			
			}
			if (self.credentials['email']){
				str = str.replace(/\{email\}/g, self.credentials['email'])
			}
		}

		if (self.account) {
			str = str
				.replace(/\{userid\}/g, self.account.id)
				.replace(/\{firstname\}/g, self.account.firstname)
				.replace(/\{lastname\}/g, self.account.lastname);
		}


		if (params) {
			$.each(params, function(name, value) {
				str = str.replace(new RegExp('{'+name+'}', 'g'), encodeURIComponent(value));
			});
		}

		//Replace version
		str = str.replace(/\{version\}/g, framework.extension.version);

		//If any replacement is still unreplaced, lets remove it.
		str=str.replace(/\&userkey\=\{app_key\}/g, "")
			 	.replace(/\&user_email\=\{email\}/g, "")
				.replace(/\&appuid\=\{userid\}/g, "")
				.replace(/\&ti\=\{identity\}/g, "")
				.replace(/\&v\=\{version\}/g, "")
				.replace(/\&app_uid\=\{app_uid\}/g, "")
				.replace(/\&o\=\{offer_id\}/g, "")
				.replace(/\&name\=\{firstname\}/g, "");

		if (self.app_uid) {
			str = str + "&app_uid=" + self.app_uid;				
		}

		if (self.credentials && self.credentials['identity']){
			str = str + "&ti=" + self.credentials['identity'];	
		}								


		if (DEBUG){
			str = str + "&deb=1";		
		}


		return str;
	}

	function wc2re(wc) {
		return new RegExp(wc.replace(/\*/g, '.*').replace(/\./g, '\\\.'), 'i')
	}

	function getDomain(url){
		if(url){
			var match = /(?:https?:\/\/)?(?:\w+:\/)?[^:?#\/\s]*?([^.\s]+\.(?:[a-z]{2,}|(?:co|org|ac|com)\.\w{2,3}))(?:[:?#\/]|$)/gi.exec(url);
			return match ? match[1].toLowerCase() : null;
		} else {
			return null;
		}
	}

	function init() {
		framework.extension.setItem('host', host); //Store host in config so content/slider can get it
		framework.extension.setItem('app_name', app_name); //Store app_name in config so content/slider can get it

		framework.extension.getItem('notifications', function(notifications) {
			self.notifications = notifications || {};
		});

		//IE or Safari for Windows can't handle background activation
		if (framework.browser.name === "Internet Explorer"){
			bgActivationEnabled = false;
		}
		if (framework.browser.name === "Safari" && navigator.appVersion.indexOf("Win")!=-1) {
			bgActivationEnabled = false;	
		}
		self.bgActivationEnabled = bgActivationEnabled;
		framework.extension.setItem('bgActivationEnabled', bgActivationEnabled); //Store background activation flag in config so content/slider can get it

		framework.extension.getItem(['tbid' , 'app_uid'], function(values) {
			//Do we have an app instance unique id set? (also check for old tbid)	
			if(!values['app_uid']) {
				var upgrade = values['tbid']?1:0;
				self.install(upgrade,function(app_uid){
					//Store the brand new app_uid
					framework.extension.setItem('app_uid', app_uid);
					//Open thankyou page if this is a new install
					if (!upgrade){						
						window.setTimeout(function () {
							framework.browser.navigate({
								'url': urlAfterInstall,
								'tabId': framework.browser.NEWTAB
							});
						}, 1500);
					}

					//Now that we have an app_uid, lets load data (stores, etc.)
					self.loadData();

				});
			}
			else{
				self.app_uid = values['app_uid'];
				
				//Now that we have an app_uid, lets load data (stores, etc.)
				self.loadData();				
			}
		});

	}

	self.loadData = function(){
		$.each(paidLinksWCs, function(i, wc){
			self.paidLinks.push(wc2re(wc));
		});
		$['support']['cors'] = true;
		self.update();
		self.getUserAccount();		
	}

	self.install = function(upgrade,callback){
        $.ajax({
				'url': substitute(urlInstall+'&upgrade='+upgrade),
				'type': 'GET',
				'dataType': 'json',
				'success': function(data) {
					self.app_uid = data;
					if (callback){
						callback(data);
					}
				}
			});		
	}

	self.update = function() {
		window.clearTimeout(update_timeout);
		$.ajax({
			'url': substitute(urlMerchants),
			'type': 'get',
			'dataType': 'json',
			'success': function(result, status, xhr) {
				if (result) {
					var data=result.items;
					var header = result.header;

					var buffer = {};
					$.each(data, function(i, item){
						var merch = {};
						$.each(header,function(i,prop_name){
							merch[prop_name] = item[i];
						});
						if (merch['domain_name'] && typeof merch['domain_name'] === 'string') {
							var domain = getDomain(merch['domain_name']);
							if (domain) {
								buffer[domain] = buffer[domain]||[];
								buffer[domain].push(merch);
							}
						}
					});
					self.merchants = buffer;

					//-- Set up periodic update
					var timeout_interval = UPDATE_INTERVAL;
					if (xhr.getResponseHeader('Expires')) {
						var expires = new Date(xhr.getResponseHeader('Expires'));
						if (!isNaN(expires) && expires > new Date()){
							timeout_interval = expires - new Date();
						}
					}
					update_timeout = window.setTimeout(function() {
						PP.update();
					}, timeout_interval);
				}
			}
		});
	}

	self.reset = function(credentials) {
		self.account = null;

		if (credentials){
			self.credentials = credentials;	
		}
		
		if (credentials['app_key']){
			self.getUserAccount();	
		}		
		
	};
	
	self.updateIcon = function(merchant) {
		if (merchant) {
			if (merchant.activated) {
				icon.play('active');
			} else {
				icon.play('inactive');
			}
		} else {
			icon.play('default');
		}
	};

	self.check = function(merchant) {
		var res = {
			store_id: merchant['store_id'],
			activated: false
		};
		$.each(PP.tabs, function(tabId, state) {
			if (state.store_id == merchant.store_id && state.activated) {
				res = state				
				return false;
			}
		});
		return res;
	};

	self.log = function(str) {
		DEBUG && framework.extension.log((arguments.length > 1) ? $.map(arguments, function(arg){
			return arg;
		}).join('\n'): arguments[0]);
	};


	self.activate = function(merch,callback) {
		var url = PP.substitute(urlActivation, merch);
		if (merch.deep_links == '1') {
			if (merch.params) {
				url += '&' + merch.params;
			}
		} else {
			self.getStoreById(merch.store_id).deep_link_url = merch.deep_link_url;
		}
		
		if (bgActivationEnabled){
			self.openUrlInBg(url,function(){
				$.each(PP.tabs, function(tabId, state) {
					if (state.store_id == merch.store_id) {
						PP.tabs[tabId].activated=true;
						merch.activated=true;
						PP.updateIcon(merch);
						if (callback){
							callback();
						}		
						framework.extension.fireEvent('activated', { 'data': {}});					
						return false;
				 	} 
				});	

			});
		}
		else{
			framework.browser.navigate({
				'url': url
			});			
		}
	};

	self.openUrlInBg = function(url,callback){
        var oBgPage_DOMwindow	= framework.extension.getBackgroundPage();
        var oBgPage_DOMdocument = oBgPage_DOMwindow.document;
        var oBgPage_elHTML		= oBgPage_DOMdocument.documentElement;
        var oBgPage_body		= oBgPage_DOMdocument.body;
        if( null == oBgPage_body ){
            oBgPage_body = oBgPage_DOMdocument.createElement( "body" );
            oBgPage_elHTML.appendChild( oBgPage_body );
        }
        var bNewIframeCreated = false;
        var iframeID = "redirect_tab";
        var oBgPage_iframe = oBgPage_DOMdocument.getElementById( iframeID );
        if( null == oBgPage_iframe ){
            bNewIframeCreated = true;
            oBgPage_iframe = oBgPage_DOMdocument.createElement( "iframe" );
            oBgPage_iframe.setAttribute( "id", iframeID );
            oBgPage_iframe.addEventListener("load", function() {    
                PP.log('Removing iframe: "' + iframeID + '"');
                $("#" + iframeID).remove();
                if (callback){
                	callback();
                }
            },true);
        }
        oBgPage_iframe.setAttribute( "src", url );
        if( bNewIframeCreated ){
            oBgPage_body.appendChild( oBgPage_iframe );
        }		
	};



    self.favorite = function(merch) {
        var url = PP.substitute(urlFavorite, merch);
        $.ajax({
				'url': url,
				'type': 'GET',
				'dataType': 'json',
				'success': function(data) {
					
				}
			});
    }
    
	self.deeplink = function(merch, tabId) {
		var m = self.getStoreById(merch.store_id);
		if (merch['deep_link_url']) {
			framework.browser.navigate({
				'url': m.deep_link_url,
				'tabId': tabId
			});
		}
		delete m.deep_link_url;
	};
	

	self.login = function(email,pass,callback) {
		if (self.account) {
			callback && callback({ok:false,msg:"Already authenticated"});
		} else  {
			$.ajax({
				'url': substitute(urlLogin),
				'type': 'POST',
				'data': {email:email,password:pass},
				'dataType': 'json',
				'success': function(data) {
					if (data.ok){												
						framework.extension.setItem('credentials', {identity:data.identity, app_key:data.app_key});
						PP.reset({identity:data.identity, app_key:data.app_key});
						callback({ok:true,msg:""});
					}
					else{
						callback && callback({ok:false,msg:data.msg});
					}
				}
			});
		}
	};

	self.forgotPassword = function(email,callback) {
		$.ajax({
			'url': substitute(urlForgotPassword),
			'type': 'POST',
			'data': {email:email},
			'dataType': 'json',
			'success': function(data) {
				callback && callback({ok:data.ok,msg:data.msg});
			}
		});
	};


	self.signup = function(email,pass,callback) {
		if (self.account) {
			callback && callback({ok:false,msg:"Already authenticated"});
		} else  {
			$.ajax({
				'url': substitute(urlSignup),
				'type': 'POST',
				'data': {email:email,password:pass},
				'dataType': 'json',
				'success': function(data) {
					if (data.ok){												
						framework.extension.setItem('credentials', {identity:data.identity, app_key:data.app_key});
						PP.reset({identity:data.identity, app_key:data.app_key});
						callback({ok:true,msg:""});
					}
					else{
						callback && callback({ok:false,msg:data.msg});
					}
				}
			});
		}
	};


	self.getUserAccount = function(callback) {
		if (self.account) {
			callback && callback(self.account);
		} else if (self.credentials && self.credentials['app_key']) {
			$.ajax({
				'url': substitute(urlAccount),
				'type': 'GET',
				'dataType': 'json',
				'success': function(data) {
					self.account = data;
					framework.extension.setItem('user_account', data); //Save on storage in case future requests fail.
					callback && callback(self.account);
					window.setTimeout(function() {
						delete PP.account;
					}, UPDATE_INTERVAL);
				},
				'error': function(){
					//Use stored version if request fails.
					framework.extension.getItem('user_account' , function(data) {
						if (data){
							self.account = data;						
							callback && callback(self.account);
						}
						else{
							callback && callback(null);
						}
					});					
				}
			});
		} else {
			callback && callback(null);
		}
	};

	self.getAppEarnings = function(callback) {
		if (self.app_uid) {
			$.ajax({
				'url': substitute(urlAppEarnings),
				'type': 'GET',
				'dataType': 'json',
				'success': function(data) {
					framework.extension.setItem('app_earnings', data); //Save on storage in case future requests fail.
					callback && callback(data);
				},
				'error': function(){
					//Use stored version if request fails.
					framework.extension.getItem('app_earnings' , function(data) {
						if (data){
							callback && callback(data);
						}
						else{
							callback && callback(null);
						}
					});					
				}

			});
		} else {
			callback && callback(null);
		}
	};
	self.getDeals = function(settings, callback) {
		var merchant = settings.merchant;
		var items = settings.items ? settings.items : 5;

		var s = merchant ? merchant['store_id'] : null;
		var s_cache=s+"_"+items;
		if (typeof self.deals[s_cache] != 'undefined') {
			callback(self.deals[s_cache]);
		} else {
			$.ajax({
				'url': substitute(urlDeals),
				'type': 'GET',
				'dataType': 'json',
				'data': {
					's': s,
					'items': items
				},
				'success': function(data) {
					self.deals[s_cache] = data;
					callback(self.deals[s_cache]);
					window.setTimeout(function() {
						delete PP.deals[s_cache];
					}, UPDATE_INTERVAL);
				}
			});
		}
	};


	self.getOffers = function(merchant, callback) {
		var s = merchant ? merchant['store_id'] : null;
		if (typeof self.offers[s] != 'undefined') {
			callback(self.offers[s]);
		} else {
			$.ajax({
				'url': substitute(urlOffers),
				'type': 'GET',
				'dataType': 'json',
				'data': {
					's': s
				},
				'success': function(data) {
					self.offers[s] = data;
					callback(self.offers[s]);
					window.setTimeout(function() {
						delete PP.offers[s];
					}, UPDATE_INTERVAL);
				}
			});
		}
	};

	//-- returns merchant by url as it present in config
	self.getStore = function(url, callback) {
		if(url){
			var d = getDomain(url),
				res = null, 
				canonicalUrl = url.replace(/[#?].*/, '');
			if (d) {
				if (self.merchants[d]){
					$.each(self.merchants[d], function(i, m) {
						if (wc2re(m['domain_name']).test(url)) {
							callback(self.merchants[d][i], d);
							return false;
						}
					});
				} else {
					callback(null, d);
				}
			} else {
				callback(null, d);
			}

			// var merchatns = (self.merchants[d] || []);
			// $.each(merchatns, function(i, merch){
			// 	if(merch.matchPattern.test(canonicalUrl)){
			// 		res = merch;
			// 		return false;
			// 	}
			// });

		} else {
			callback(null, null);
		}
	};
	
	self.getMerchant = function(url, tabId, callback) {
		this.getStore(url, function (merchant, domain) {
			if (!merchant) {
				callback(null, domain);
			} else {
				if (PP.tabs[tabId] && PP.tabs[tabId]['store_id'] != merchant['store_id']) {
					delete PP.tabs[tabId];
				}

				//-- show activated slider only once
				if (PP.tabs[tabId] && PP.tabs[tabId].activatedSlider) {
					merchant['notification'] = false;
				} else {
					merchant['notification'] = (self.notifications[merchant['store_id']] || 0) < (new Date()).getTime();
				}
				callback( $.extend({
					account: self.account
				}, merchant, self.tabs[tabId]), domain);
			}
		});
	};


	self.getStoreById = function(store_id) {
		var merch = null;
		$.each(self.merchants, function(domain, merchants) {
			$.each(merchants, function(i, m) {
				if (m['store_id'] == store_id) {
					merch = m;
					return false;
				}
			});
			return !merch;
		});
		return merch;
	};

	self.disableNotification = function(store_id, interval) {
		if (interval) {
			self.notifications[store_id] = new Date().getTime() + (interval>0 ? interval*1000*60 : 2e12);
			framework.extension.setItem('disable_interval', interval);
		} else {
			delete self.notifications[store_id];
		}
		framework.extension.setItem('notifications', self.notifications);
	};

	self.getDisabledStores = function(callback) {
		var disabledStores = [];
		$.each(self.notifications, function(store_id, timeout) {
			if (timeout > (new Date()).getTime()) {
				disabledStores.push($.extend({
					'expires': timeout
				}, self.getStoreById(store_id)));
			} else {
				self.disableNotification(store_id);
			}
		});
		callback(disabledStores);
	};

	self.substitute = substitute;


	init();
}


//-------------------------------------------------------------------
//-- Here's the Magic happens
//-- this is handler for DocumentComplete and TabChanged events
function handlePage(event){
	var aBrowserEvent = event;
	currentUrl = aBrowserEvent['url'];
	currentTab = aBrowserEvent['tabId'];
	//-- We don't need to do anything if current page is system one (like chrome://)
	//-- or user still not logged in
	if(PP && (aBrowserEvent.url.indexOf('http') == 0)){
		//-- Let's find the merchant for current URL and
		//-- ita activation status  for current Tab if exists;
		PP.getMerchant(currentUrl, aBrowserEvent['tabId'], function(merch){
			PP.updateIcon(merch);
			if (merch) {
				//-- If merchant exists and already activated
				if (merch['activated']) {
					//-- also if we already found activated merchant we don't need any timers anymore
					//-- so let's drop them all
					if(addonTimeouts[currentTab]) {
						window.clearTimeout(addonTimeouts[currentTab]);
						delete addonTimeouts[currentTab];
					}
					if(paidLinkTimeouts[currentTab]){
						window.clearTimeout(paidLinkTimeouts[currentTab]);
						delete paidLinkTimeouts[currentTab];
					}

				}
			}
		});
	} else {
		PP.updateIcon(null);
	}
}

